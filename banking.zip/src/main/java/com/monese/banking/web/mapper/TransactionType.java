package com.monese.banking.web.mapper;

public enum TransactionType {
    INBOUND, OUTBOUND
}
